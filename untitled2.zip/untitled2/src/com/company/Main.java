package com.company;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class Main {

    public static void main(String[] args) throws IOException {

        int[][] arrayofsth = {
                {0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0},
        };


        do3squares(arrayofsth);


        while (searchZero(arrayofsth)) {
            evenMoreMagic(arrayofsth);
        }


        for (int[] outer : arrayofsth
        ) {
            for (int number : outer
            ) {
                System.out.print(number + " ");
            }
            System.out.println("");
        }


    }


    // -----------------------------------------------------------------------------------

    public static void do3squares(int[][] array) {

        ArrayList<Integer> takenNumber = new ArrayList<>();
        Random random = new Random();
        int number;


        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                do {
                    number = random.nextInt(9) + 1;
                } while (takenNumber.contains(number));
                array[i][j] = number;
                takenNumber.add(number);
            }
        }

        takenNumber = new ArrayList<>();
        for (int i = 3; i < 6; i++) {
            for (int j = 3; j < 6; j++) {
                do {
                    number = random.nextInt(9) + 1;
                } while (takenNumber.contains(number));
                array[i][j] = number;
                takenNumber.add(number);
            }
        }

        takenNumber = new ArrayList<>();
        for (int i = 6; i < 9; i++) {
            for (int j = 6; j < 9; j++) {
                do {
                    number = random.nextInt(9) + 1;
                } while (takenNumber.contains(number));
                array[i][j] = number;
                takenNumber.add(number);
            }
        }


    }


    public static ArrayList<Field> magic(int[][] array) {

        //list of empty fields, we can assing to them number of possibilities, and sort by it
        ArrayList<Field> listOfFields = new ArrayList<>();

        // iterate over array
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {

                //only check and create empty fields
                if (array[i][j] == 0) {

                    Field field = new Field(i, j);

                    // iterate through all 9 numbers, if any is available, this number is added to field available numbers
                    for (int n = 1; n <= 9; n++) {
                        if (Checker.checkAll(i, j, n, array)) {
                            field.avaiableNumbers.add(n);
                        }
                    }
                    // now, in the and we have list of all field, and how many number are available in them
                    listOfFields.add(field);
                }
            }
        }

        return listOfFields;
    }

    public static void evenMoreMagic(int[][] array) {

        ArrayList<Field> fieldsOfThisLevel = magic(array);

        // now, we sort array  of fields, so 1st field is field with less amount of opportunity (less amount of possible number to insert it)
        Collections.sort(fieldsOfThisLevel);

        // we get information about field with lowest possibilities
        int y = fieldsOfThisLevel.get(0).y;
        int x = fieldsOfThisLevel.get(0).x;

        //and take one of random number from it
        Random random = new Random();
        int randomNumber = random.nextInt(fieldsOfThisLevel.get(0).avaiableNumbers.size());
        int number = fieldsOfThisLevel.get(0).avaiableNumbers.get(randomNumber);
        fieldsOfThisLevel.get(0).avaiableNumbers.remove(randomNumber);

        // change number from field list into board number
        array[y][x] = number;

        // just to know whats going on
//        for (int[] outer : array
//        ) {
//            for (int numberx : outer
//            ) {
//                System.out.print(numberx + " ");
//            }
//            System.out.println("");
//        }

        try {
            evenMoreMagic(array);
        } catch (Exception e) {
            // check if its ready or not (like in this song)
            // if not, reset array, and start from begining
            if (searchZero(array)) {
                int[][] tempArray = {
                        {0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0},
                };

                array = tempArray;

                do3squares(array);

                evenMoreMagic(array);

            }else{
                System.out.println("just to end loop, it doesnt work with if statement, or im noob:-(");
            }
            
        }


    }

    public static boolean searchZero(int[][] array) {

        for (int[] outerArray : array
        ) {
            for (int number : outerArray
            ) {
                if (number == 0) return true;
            }
        }
        return false;
    }

}
