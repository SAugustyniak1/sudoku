package com.company;

import java.util.ArrayList;

public class Field implements Comparable{

    int y;
    int x;

    ArrayList<Integer> avaiableNumbers = new ArrayList<>();

    public Field(int y, int x) {
        this.y = y;
        this.x = x;
    }

    @Override
    public int compareTo(Object o) {
        Field tempField = (Field)o;

        if(this.avaiableNumbers.size()>tempField.avaiableNumbers.size()) return 1;
        if(this.avaiableNumbers.size()<tempField.avaiableNumbers.size()) return -1;
        return 0;

    }
}
