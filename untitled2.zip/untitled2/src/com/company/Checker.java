package com.company;

public class Checker {


    public static boolean checkRow(int row, int number, int[][] board) {

        for (int i = 0; i < 9; i++) {
//            System.out.println(board[row][i]);
            if (board[row][i] == number) {
                return false;
            }
        }

        return true;
    }

    public static boolean checkColumn(int col, int number, int[][] board) {
        for (int i = 0; i < 9; i++) {
//            System.out.println(board[i][col]);
            if (board[i][col] == number) {
                return false;
            }
        }

        return true;
    }

    public static boolean checkSquare(int row, int col, int number, int[][] board) {

        int r = row - row % 3;
        int c = col - col % 3;
        for (int i = r; i < r + 3; i++) {
            for (int j = c; j <c + 3; j++){
//                System.out.println(board[i][j]);
                if (board[i][j] == number)
                    return false;
            }
        }
        return true;
    }


    public static boolean checkAll(int row, int col, int number, int[][] board) {

        return checkRow(row, number, board) && checkColumn(col, number, board) && checkSquare(row, col, number, board);
    }

    public static boolean checkWinner(int[][] board){

        for (int i=0; i<9; i++){
            if(!checkColumn(i, 0, board)) return false;
            if(!checkRow(i,0,board)) return false;
        }
        return true;
    }

}
