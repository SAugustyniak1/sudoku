package sample;

public class AllHistoryCounter {
    int x=0;
}
