package sample;

public class Player {


    //Player make a move
    // if filed was taken at start (taken board) player cant move there, if it was 0 player can
    // if player chose 0, so clear field, player can always make a move
    // if checker check move is avaiable, player can do it
    public static boolean Move(int y, int x, int number, int[][] board, int[][] takenBoard) {

        if (takenBoard[y][x] == 0) {
            if (number == 0) {
                board[y][x] = 0;
                return true;
            } else {
                if (Checker.checkAll(y, x, number, board)) {
                    board[y][x] = number;
                    return true;
                } else {
                    return false;
                }
            }
        } else {
            return false;
        }


    }
}
