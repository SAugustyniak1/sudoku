package sample;

public class HistoryCounter {

    int x= 0;
}
