package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        primaryStage.setTitle("Sudoku");

        // sudoku board grid pane
        Board board = new Board();

        GridPane grid1 = new GridPane();
        grid1.setPadding( new Insets(25));
        grid1.setAlignment(Pos.CENTER);
        grid1.setOpacity(0.8);



        // ------------------------------------------------------------------------------------------------

        // Button creation 1st raw

        //-------------------------------------------------------------------------------------------------

        ButtonWithID b00 = new ButtonWithID(100);
        Controller.setButtonStyle(b00,board);
        if(board.board[0][0] != 0){
            b00.setText(Integer.toString(board.board[0][0]));
        }
        b00.setOnAction(event -> Controller.clickButton(b00, board));


        ButtonWithID b01 = new ButtonWithID(101);
        Controller.setButtonStyle(b01,board);
        if(board.board[0][1] != 0){
            b01.setText(Integer.toString(board.board[0][1]));
        }
        b01.setOnAction(event -> Controller.clickButton(b01, board));

        ButtonWithID b02 = new ButtonWithID(102);
        Controller.setButtonStyle(b02,board);
        if(board.board[0][2] != 0){
            b02.setText(Integer.toString(board.board[0][2]));
        }
        b02.setOnAction(event -> Controller.clickButton(b02, board));

        ButtonWithID b03 = new ButtonWithID(103);
        Controller.setButtonStyle(b03,board);
        if(board.board[0][3] != 0){
            b03.setText(Integer.toString(board.board[0][3]));
        }
        b03.setOnAction(event -> Controller.clickButton(b03, board));

        ButtonWithID b04 = new ButtonWithID(104);
        Controller.setButtonStyle(b04,board);
        if(board.board[0][4] != 0){
            b04.setText(Integer.toString(board.board[0][4]));
        }
        b04.setOnAction(event -> Controller.clickButton(b04, board));

        ButtonWithID b05 = new ButtonWithID(105);
        Controller.setButtonStyle(b05,board);
        if(board.board[0][5] != 0){
            b05.setText(Integer.toString(board.board[0][5]));
        }
        b05.setOnAction(event -> Controller.clickButton(b05, board));

        ButtonWithID b06 = new ButtonWithID(106);
        Controller.setButtonStyle(b06,board);
        if(board.board[0][6] != 0){
            b06.setText(Integer.toString(board.board[0][6]));
        }
        b06.setOnAction(event -> Controller.clickButton(b06, board));

        ButtonWithID b07 = new ButtonWithID(107);
        Controller.setButtonStyle(b07,board);
        if(board.board[0][7] != 0){
            b07.setText(Integer.toString(board.board[0][7]));
        }
        b07.setOnAction(event -> Controller.clickButton(b07, board));

        ButtonWithID b08 = new ButtonWithID(108);
        Controller.setButtonStyle(b08,board);
        if(board.board[0][8] != 0){
            b08.setText(Integer.toString(board.board[0][8]));
        }
        b08.setOnAction(event -> Controller.clickButton(b08, board));

        // --------------------------------------------------------------------------------
        // Button creation row 2


        ButtonWithID b10 = new ButtonWithID(110);
        Controller.setButtonStyle(b10,board);
        if(board.board[1][0] != 0){
            b10.setText(Integer.toString(board.board[1][0]));
        }
        b10.setOnAction(event -> Controller.clickButton(b10, board));


        ButtonWithID b11 = new ButtonWithID(111);
        Controller.setButtonStyle(b11,board);
        if(board.board[1][1] != 0){
            b11.setText(Integer.toString(board.board[1][1]));
        }
        b11.setOnAction(event -> Controller.clickButton(b11, board));

        ButtonWithID b12 = new ButtonWithID(112);
        Controller.setButtonStyle(b12,board);
        if(board.board[1][2] != 0){
            b12.setText(Integer.toString(board.board[1][2]));
        }
        b12.setOnAction(event -> Controller.clickButton(b12, board));

        ButtonWithID b13 = new ButtonWithID(113);
        Controller.setButtonStyle(b13,board);
        if(board.board[1][3] != 0){
            b13.setText(Integer.toString(board.board[1][3]));
        }
        b13.setOnAction(event -> Controller.clickButton(b13, board));

        ButtonWithID b14 = new ButtonWithID(114);
        Controller.setButtonStyle(b14,board);
        if(board.board[1][4] != 0){
            b14.setText(Integer.toString(board.board[1][4]));
        }
        b14.setOnAction(event -> Controller.clickButton(b14, board));

        ButtonWithID b15 = new ButtonWithID(115);
        Controller.setButtonStyle(b15,board);
        if(board.board[1][5] != 0){
            b15.setText(Integer.toString(board.board[1][5]));
        }
        b15.setOnAction(event -> Controller.clickButton(b15, board));

        ButtonWithID b16 = new ButtonWithID(116);
        Controller.setButtonStyle(b16,board);
        if(board.board[1][6] != 0){
            b16.setText(Integer.toString(board.board[1][6]));
        }
        b16.setOnAction(event -> Controller.clickButton(b16, board));

        ButtonWithID b17 = new ButtonWithID(117);
        Controller.setButtonStyle(b17,board);
        if(board.board[1][7] != 0){
            b17.setText(Integer.toString(board.board[1][7]));
        }
        b17.setOnAction(event -> Controller.clickButton(b17, board));

        ButtonWithID b18 = new ButtonWithID(118);
        Controller.setButtonStyle(b18,board);
        if(board.board[1][8] != 0){
            b18.setText(Integer.toString(board.board[1][8]));
        }
        b18.setOnAction(event -> Controller.clickButton(b18, board));

        // --------------------------------------------------------------------------------
        // Button creation row 3


        ButtonWithID b20 = new ButtonWithID(120);
        Controller.setButtonStyle(b20,board);
        if(board.board[2][0] != 0){
            b20.setText(Integer.toString(board.board[2][0]));
        }
        b20.setOnAction(event -> Controller.clickButton(b20, board));


        ButtonWithID b21 = new ButtonWithID(121);
        Controller.setButtonStyle(b21,board);
        if(board.board[2][1] != 0){
            b21.setText(Integer.toString(board.board[2][1]));
        }
        b21.setOnAction(event -> Controller.clickButton(b21, board));

        ButtonWithID b22 = new ButtonWithID(122);
        Controller.setButtonStyle(b22,board);
        if(board.board[2][2] != 0){
            b22.setText(Integer.toString(board.board[2][2]));
        }
        b22.setOnAction(event -> Controller.clickButton(b22, board));

        ButtonWithID b23 = new ButtonWithID(123);
        Controller.setButtonStyle(b23,board);
        if(board.board[2][3] != 0){
            b23.setText(Integer.toString(board.board[2][3]));
        }
        b23.setOnAction(event -> Controller.clickButton(b23, board));

        ButtonWithID b24 = new ButtonWithID(124);
        Controller.setButtonStyle(b24,board);
        if(board.board[2][4] != 0){
            b24.setText(Integer.toString(board.board[2][4]));
        }
        b24.setOnAction(event -> Controller.clickButton(b24, board));

        ButtonWithID b25 = new ButtonWithID(125);
        Controller.setButtonStyle(b25,board);
        if(board.board[2][5] != 0){
            b25.setText(Integer.toString(board.board[2][5]));
        }
        b25.setOnAction(event -> Controller.clickButton(b25, board));

        ButtonWithID b26 = new ButtonWithID(126);
        Controller.setButtonStyle(b26,board);
        if(board.board[2][6] != 0){
            b26.setText(Integer.toString(board.board[2][6]));
        }
        b26.setOnAction(event -> Controller.clickButton(b26, board));

        ButtonWithID b27 = new ButtonWithID(127);
        Controller.setButtonStyle(b27,board);
        if(board.board[2][7] != 0){
            b27.setText(Integer.toString(board.board[2][7]));
        }
        b27.setOnAction(event -> Controller.clickButton(b27, board));

        ButtonWithID b28 = new ButtonWithID(128);
        Controller.setButtonStyle(b28,board);
        if(board.board[2][8] != 0){
            b28.setText(Integer.toString(board.board[2][8]));
        }
        b28.setOnAction(event -> Controller.clickButton(b28, board));


        // --------------------------------------------------------------------------------
        // Button creation row 4


        ButtonWithID b30 = new ButtonWithID(130);
        Controller.setButtonStyle(b30,board);
        if(board.board[3][0] != 0){
            b30.setText(Integer.toString(board.board[3][0]));
        }
        b30.setOnAction(event -> Controller.clickButton(b30, board));


        ButtonWithID b31 = new ButtonWithID(131);
        Controller.setButtonStyle(b31,board);
        if(board.board[3][1] != 0){
            b31.setText(Integer.toString(board.board[3][1]));
        }
        b31.setOnAction(event -> Controller.clickButton(b31, board));

        ButtonWithID b32 = new ButtonWithID(132);
        Controller.setButtonStyle(b32,board);
        if(board.board[3][2] != 0){
            b32.setText(Integer.toString(board.board[3][2]));
        }
        b32.setOnAction(event -> Controller.clickButton(b32, board));

        ButtonWithID b33 = new ButtonWithID(133);
        Controller.setButtonStyle(b33,board);
        if(board.board[3][3] != 0){
            b33.setText(Integer.toString(board.board[3][3]));
        }
        b33.setOnAction(event -> Controller.clickButton(b33, board));

        ButtonWithID b34 = new ButtonWithID(134);
        Controller.setButtonStyle(b34,board);
        if(board.board[3][4] != 0){
            b34.setText(Integer.toString(board.board[3][4]));
        }
        b34.setOnAction(event -> Controller.clickButton(b34, board));

        ButtonWithID b35 = new ButtonWithID(135);
        Controller.setButtonStyle(b35,board);
        if(board.board[3][5] != 0){
            b35.setText(Integer.toString(board.board[3][5]));
        }
        b35.setOnAction(event -> Controller.clickButton(b35, board));

        ButtonWithID b36 = new ButtonWithID(136);
        Controller.setButtonStyle(b36,board);
        if(board.board[3][6] != 0){
            b36.setText(Integer.toString(board.board[3][6]));
        }
        b36.setOnAction(event -> Controller.clickButton(b36, board));

        ButtonWithID b37 = new ButtonWithID(137);
        Controller.setButtonStyle(b37,board);
        if(board.board[3][7] != 0){
            b37.setText(Integer.toString(board.board[3][7]));
        }
        b37.setOnAction(event -> Controller.clickButton(b37, board));

        ButtonWithID b38 = new ButtonWithID(138);
        Controller.setButtonStyle(b38,board);
        if(board.board[3][8] != 0){
            b38.setText(Integer.toString(board.board[3][8]));
        }
        b38.setOnAction(event -> Controller.clickButton(b38, board));

        // --------------------------------------------------------------------------------
        // Button creation row 5


        ButtonWithID b40 = new ButtonWithID(140);
        Controller.setButtonStyle(b40,board);
        if(board.board[4][0] != 0){
            b40.setText(Integer.toString(board.board[4][0]));
        }
        b40.setOnAction(event -> Controller.clickButton(b40, board));


        ButtonWithID b41 = new ButtonWithID(141);
        Controller.setButtonStyle(b41,board);
        if(board.board[4][1] != 0){
            b41.setText(Integer.toString(board.board[4][1]));
        }
        b41.setOnAction(event -> Controller.clickButton(b41, board));

        ButtonWithID b42 = new ButtonWithID(142);
        Controller.setButtonStyle(b42,board);
        if(board.board[4][2] != 0){
            b42.setText(Integer.toString(board.board[4][2]));
        }
        b42.setOnAction(event -> Controller.clickButton(b42, board));

        ButtonWithID b43 = new ButtonWithID(143);
        Controller.setButtonStyle(b43,board);
        if(board.board[4][3] != 0){
            b43.setText(Integer.toString(board.board[4][3]));
        }
        b43.setOnAction(event -> Controller.clickButton(b43, board));

        ButtonWithID b44 = new ButtonWithID(144);
        Controller.setButtonStyle(b44,board);
        if(board.board[4][4] != 0){
            b44.setText(Integer.toString(board.board[4][4]));
        }
        b44.setOnAction(event -> Controller.clickButton(b44, board));

        ButtonWithID b45 = new ButtonWithID(145);
        Controller.setButtonStyle(b45,board);
        if(board.board[4][5] != 0){
            b45.setText(Integer.toString(board.board[4][5]));
        }
        b45.setOnAction(event -> Controller.clickButton(b45, board));

        ButtonWithID b46 = new ButtonWithID(146);
        Controller.setButtonStyle(b46,board);
        if(board.board[4][6] != 0){
            b46.setText(Integer.toString(board.board[4][6]));
        }
        b46.setOnAction(event -> Controller.clickButton(b46, board));

        ButtonWithID b47 = new ButtonWithID(147);
        Controller.setButtonStyle(b47,board);
        if(board.board[4][7] != 0){
            b47.setText(Integer.toString(board.board[4][7]));
        }
        b47.setOnAction(event -> Controller.clickButton(b47, board));

        ButtonWithID b48 = new ButtonWithID(148);
        Controller.setButtonStyle(b48,board);
        if(board.board[4][8] != 0){
            b48.setText(Integer.toString(board.board[4][8]));
        }
        b48.setOnAction(event -> Controller.clickButton(b48, board));

        // --------------------------------------------------------------------------------
        // Button creation row 6


        ButtonWithID b50 = new ButtonWithID(150);
        Controller.setButtonStyle(b50,board);
        if(board.board[5][0] != 0){
            b50.setText(Integer.toString(board.board[5][0]));
        }
        b50.setOnAction(event -> Controller.clickButton(b50, board));


        ButtonWithID b51 = new ButtonWithID(151);
        Controller.setButtonStyle(b51,board);
        if(board.board[5][1] != 0){
            b51.setText(Integer.toString(board.board[5][1]));
        }
        b51.setOnAction(event -> Controller.clickButton(b51, board));

        ButtonWithID b52 = new ButtonWithID(152);
        Controller.setButtonStyle(b52,board);
        if(board.board[5][2] != 0){
            b52.setText(Integer.toString(board.board[5][2]));
        }
        b52.setOnAction(event -> Controller.clickButton(b52, board));

        ButtonWithID b53 = new ButtonWithID(153);
        Controller.setButtonStyle(b53,board);
        if(board.board[5][3] != 0){
            b53.setText(Integer.toString(board.board[5][3]));
        }
        b53.setOnAction(event -> Controller.clickButton(b53, board));

        ButtonWithID b54 = new ButtonWithID(154);
        Controller.setButtonStyle(b54,board);
        if(board.board[5][4] != 0){
            b54.setText(Integer.toString(board.board[5][4]));
        }
        b54.setOnAction(event -> Controller.clickButton(b54, board));

        ButtonWithID b55 = new ButtonWithID(155);
        Controller.setButtonStyle(b55,board);
        if(board.board[5][5] != 0){
            b55.setText(Integer.toString(board.board[5][5]));
        }
        b55.setOnAction(event -> Controller.clickButton(b55, board));

        ButtonWithID b56 = new ButtonWithID(156);
        Controller.setButtonStyle(b56,board);
        if(board.board[5][6] != 0){
            b56.setText(Integer.toString(board.board[5][6]));
        }
        b56.setOnAction(event -> Controller.clickButton(b56, board));

        ButtonWithID b57 = new ButtonWithID(157);
        Controller.setButtonStyle(b57,board);
        if(board.board[5][7] != 0){
            b57.setText(Integer.toString(board.board[5][7]));
        }
        b57.setOnAction(event -> Controller.clickButton(b57, board));

        ButtonWithID b58 = new ButtonWithID(158);
        Controller.setButtonStyle(b58,board);
        if(board.board[5][8] != 0){
            b58.setText(Integer.toString(board.board[5][8]));
        }
        b58.setOnAction(event -> Controller.clickButton(b58, board));

        // --------------------------------------------------------------------------------
        // Button creation row 7


        ButtonWithID b60 = new ButtonWithID(160);
        Controller.setButtonStyle(b60,board);
        if(board.board[6][0] != 0){
            b60.setText(Integer.toString(board.board[6][0]));
        }
        b60.setOnAction(event -> Controller.clickButton(b60, board));


        ButtonWithID b61 = new ButtonWithID(161);
        Controller.setButtonStyle(b61,board);
        if(board.board[6][1] != 0){
            b61.setText(Integer.toString(board.board[6][1]));
        }
        b61.setOnAction(event -> Controller.clickButton(b61, board));

        ButtonWithID b62 = new ButtonWithID(162);
        Controller.setButtonStyle(b62,board);
        if(board.board[6][2] != 0){
            b62.setText(Integer.toString(board.board[6][2]));
        }
        b62.setOnAction(event -> Controller.clickButton(b62, board));

        ButtonWithID b63 = new ButtonWithID(163);
        Controller.setButtonStyle(b63,board);
        if(board.board[6][3] != 0){
            b63.setText(Integer.toString(board.board[6][3]));
        }
        b63.setOnAction(event -> Controller.clickButton(b63, board));

        ButtonWithID b64 = new ButtonWithID(164);
        Controller.setButtonStyle(b64,board);
        if(board.board[6][4] != 0){
            b64.setText(Integer.toString(board.board[6][4]));
        }
        b64.setOnAction(event -> Controller.clickButton(b64, board));

        ButtonWithID b65 = new ButtonWithID(165);
        Controller.setButtonStyle(b65,board);
        if(board.board[6][5] != 0){
            b65.setText(Integer.toString(board.board[6][5]));
        }
        b65.setOnAction(event -> Controller.clickButton(b65, board));

        ButtonWithID b66 = new ButtonWithID(166);
        Controller.setButtonStyle(b66,board);
        if(board.board[6][6] != 0){
            b66.setText(Integer.toString(board.board[6][6]));
        }
        b66.setOnAction(event -> Controller.clickButton(b66, board));

        ButtonWithID b67 = new ButtonWithID(167);
        Controller.setButtonStyle(b67,board);
        if(board.board[6][7] != 0){
            b67.setText(Integer.toString(board.board[6][7]));
        }
        b67.setOnAction(event -> Controller.clickButton(b67, board));

        ButtonWithID b68 = new ButtonWithID(168);
        Controller.setButtonStyle(b68,board);
        if(board.board[6][8] != 0){
            b68.setText(Integer.toString(board.board[6][8]));
        }
        b68.setOnAction(event -> Controller.clickButton(b68, board));

        // --------------------------------------------------------------------------------
        // Button creation row 8


        ButtonWithID b70 = new ButtonWithID(170);
        Controller.setButtonStyle(b70,board);
        if(board.board[7][0] != 0){
            b70.setText(Integer.toString(board.board[7][0]));
        }
        b70.setOnAction(event -> Controller.clickButton(b70, board));


        ButtonWithID b71 = new ButtonWithID(171);
        Controller.setButtonStyle(b71,board);
        if(board.board[7][1] != 0){
            b71.setText(Integer.toString(board.board[7][1]));
        }
        b71.setOnAction(event -> Controller.clickButton(b71, board));

        ButtonWithID b72 = new ButtonWithID(172);
        Controller.setButtonStyle(b72,board);
        if(board.board[7][2] != 0){
            b72.setText(Integer.toString(board.board[7][2]));
        }
        b72.setOnAction(event -> Controller.clickButton(b72, board));

        ButtonWithID b73 = new ButtonWithID(173);
        Controller.setButtonStyle(b73,board);
        if(board.board[7][3] != 0){
            b73.setText(Integer.toString(board.board[7][3]));
        }
        b73.setOnAction(event -> Controller.clickButton(b73, board));

        ButtonWithID b74 = new ButtonWithID(174);
        Controller.setButtonStyle(b74,board);
        if(board.board[7][4] != 0){
            b74.setText(Integer.toString(board.board[7][4]));
        }
        b74.setOnAction(event -> Controller.clickButton(b74, board));

        ButtonWithID b75 = new ButtonWithID(175);
        Controller.setButtonStyle(b75,board);
        if(board.board[7][5] != 0){
            b75.setText(Integer.toString(board.board[7][5]));
        }
        b75.setOnAction(event -> Controller.clickButton(b75, board));

        ButtonWithID b76 = new ButtonWithID(176);
        Controller.setButtonStyle(b76,board);
        if(board.board[7][6] != 0){
            b76.setText(Integer.toString(board.board[7][6]));
        }
        b76.setOnAction(event -> Controller.clickButton(b76, board));

        ButtonWithID b77 = new ButtonWithID(177);
        Controller.setButtonStyle(b77,board);
        if(board.board[7][7] != 0){
            b77.setText(Integer.toString(board.board[7][7]));
        }
        b77.setOnAction(event -> Controller.clickButton(b77, board));

        ButtonWithID b78 = new ButtonWithID(178);
        Controller.setButtonStyle(b78,board);
        if(board.board[7][8] != 0){
            b78.setText(Integer.toString(board.board[7][8]));
        }
        b78.setOnAction(event -> Controller.clickButton(b78, board));

        // --------------------------------------------------------------------------------
        // Button creation row 8


        ButtonWithID b80 = new ButtonWithID(180);
        Controller.setButtonStyle(b80,board);
        if(board.board[8][0] != 0){
            b80.setText(Integer.toString(board.board[8][0]));
        }
        b80.setOnAction(event -> Controller.clickButton(b80, board));


        ButtonWithID b81 = new ButtonWithID(181);
        Controller.setButtonStyle(b81,board);
        if(board.board[8][1] != 0){
            b81.setText(Integer.toString(board.board[8][1]));
        }
        b81.setOnAction(event -> Controller.clickButton(b81, board));

        ButtonWithID b82 = new ButtonWithID(182);
        Controller.setButtonStyle(b82,board);
        if(board.board[8][2] != 0){
            b82.setText(Integer.toString(board.board[8][2]));
        }
        b82.setOnAction(event -> Controller.clickButton(b82, board));

        ButtonWithID b83 = new ButtonWithID(183);
        Controller.setButtonStyle(b83,board);
        if(board.board[8][3] != 0){
            b83.setText(Integer.toString(board.board[8][3]));
        }
        b83.setOnAction(event -> Controller.clickButton(b83, board));

        ButtonWithID b84 = new ButtonWithID(184);
        Controller.setButtonStyle(b84,board);
        if(board.board[8][4] != 0){
            b84.setText(Integer.toString(board.board[8][4]));
        }
        b84.setOnAction(event -> Controller.clickButton(b84, board));

        ButtonWithID b85 = new ButtonWithID(185);
        Controller.setButtonStyle(b85,board);
        if(board.board[8][5] != 0){
            b85.setText(Integer.toString(board.board[8][5]));
        }
        b85.setOnAction(event -> Controller.clickButton(b85, board));

        ButtonWithID b86 = new ButtonWithID(186);
        Controller.setButtonStyle(b86,board);
        if(board.board[8][6] != 0){
            b86.setText(Integer.toString(board.board[8][6]));
        }
        b86.setOnAction(event -> Controller.clickButton(b86, board));

        ButtonWithID b87 = new ButtonWithID(187);
        Controller.setButtonStyle(b87,board);
        if(board.board[8][7] != 0){
            b87.setText(Integer.toString(board.board[8][7]));
        }
        b87.setOnAction(event -> Controller.clickButton(b87, board));

        ButtonWithID b88 = new ButtonWithID(188);
        Controller.setButtonStyle(b88,board);
        if(board.board[8][8] != 0){
            b88.setText(Integer.toString(board.board[8][8]));
        }
        b88.setOnAction(event -> Controller.clickButton(b88, board));




        // ---------------------------------------------------------------------------------------
        // Adding buttons into grid pane
        //  Row 1

        grid1.add(b00,0,0);
        grid1.add(b01,1,0);
        grid1.add(b02,2,0);
        grid1.add(b03,3,0);
        grid1.add(b04,4,0);
        grid1.add(b05,5,0);
        grid1.add(b06,6,0);
        grid1.add(b07,7,0);
        grid1.add(b08,8,0);

        //  Row 2

        grid1.add(b10,0,1);
        grid1.add(b11,1,1);
        grid1.add(b12,2,1);
        grid1.add(b13,3,1);
        grid1.add(b14,4,1);
        grid1.add(b15,5,1);
        grid1.add(b16,6,1);
        grid1.add(b17,7,1);
        grid1.add(b18,8,1);

        //  Row 3

        grid1.add(b20,0,2);
        grid1.add(b21,1,2);
        grid1.add(b22,2,2);
        grid1.add(b23,3,2);
        grid1.add(b24,4,2);
        grid1.add(b25,5,2);
        grid1.add(b26,6,2);
        grid1.add(b27,7,2);
        grid1.add(b28,8,2);

        //  Row 4

        grid1.add(b30,0,3);
        grid1.add(b31,1,3);
        grid1.add(b32,2,3);
        grid1.add(b33,3,3);
        grid1.add(b34,4,3);
        grid1.add(b35,5,3);
        grid1.add(b36,6,3);
        grid1.add(b37,7,3);
        grid1.add(b38,8,3);

        //  Row 5

        grid1.add(b40,0,4);
        grid1.add(b41,1,4);
        grid1.add(b42,2,4);
        grid1.add(b43,3,4);
        grid1.add(b44,4,4);
        grid1.add(b45,5,4);
        grid1.add(b46,6,4);
        grid1.add(b47,7,4);
        grid1.add(b48,8,4);

        //  Row 6

        grid1.add(b50,0,5);
        grid1.add(b51,1,5);
        grid1.add(b52,2,5);
        grid1.add(b53,3,5);
        grid1.add(b54,4,5);
        grid1.add(b55,5,5);
        grid1.add(b56,6,5);
        grid1.add(b57,7,5);
        grid1.add(b58,8,5);

        //  Row 7

        grid1.add(b60,0,6);
        grid1.add(b61,1,6);
        grid1.add(b62,2,6);
        grid1.add(b63,3,6);
        grid1.add(b64,4,6);
        grid1.add(b65,5,6);
        grid1.add(b66,6,6);
        grid1.add(b67,7,6);
        grid1.add(b68,8,6);

        //  Row 8

        grid1.add(b70,0,7);
        grid1.add(b71,1,7);
        grid1.add(b72,2,7);
        grid1.add(b73,3,7);
        grid1.add(b74,4,7);
        grid1.add(b75,5,7);
        grid1.add(b76,6,7);
        grid1.add(b77,7,7);
        grid1.add(b78,8,7);

        //  Row 9

        grid1.add(b80,0,8);
        grid1.add(b81,1,8);
        grid1.add(b82,2,8);
        grid1.add(b83,3,8);
        grid1.add(b84,4,8);
        grid1.add(b85,5,8);
        grid1.add(b86,6,8);
        grid1.add(b87,7,8);
        grid1.add(b88,8,8);

        // 1st selected button
        Controller.clickButton(b00, board);


        // --------------------------------------------------------------------------------------


        // ---------------------------- CONTROL PANEL ------------------------------------------


        //--------------------------------------------------------------------------------------

        // ----number controlling game----

        GridPane controlPane = new GridPane();

        Button control1 = new Button("1");
        Controller.setControlButtonStyle(control1);
        control1.setOnAction(event -> {
            Controller.clickControlButton(1,board);
        });

        Button control2 = new Button("2");
        Controller.setControlButtonStyle(control2);
        control2.setOnAction(event -> {
            Controller.clickControlButton(2,board);
        });

        Button control3 = new Button("3");
        Controller.setControlButtonStyle(control3);
        control3.setOnAction(event -> {
            Controller.clickControlButton(3,board);
        });

        Button control4 = new Button("4");
        Controller.setControlButtonStyle(control4);
        control4.setOnAction(event -> {
            Controller.clickControlButton(4,board);
        });

        Button control5 = new Button("5");
        Controller.setControlButtonStyle(control5);
        control5.setOnAction(event -> {
            Controller.clickControlButton(5,board);
        });

        Button control6 = new Button("6");
        Controller.setControlButtonStyle(control6);
        control6.setOnAction(event -> {
            Controller.clickControlButton(6,board);
        });

        Button control7 = new Button("7");
        Controller.setControlButtonStyle(control7);
        control7.setOnAction(event -> {
            Controller.clickControlButton(7,board);
        });

        Button control8 = new Button("8");
        Controller.setControlButtonStyle(control8);
        control8.setOnAction(event -> {
            Controller.clickControlButton(8,board);
        });

        Button control9 = new Button("9");
        Controller.setControlButtonStyle(control9);
        control9.setOnAction(event -> {
            Controller.clickControlButton(9,board);
        });

        Button control0 = new Button("0");
        Controller.setControlButtonStyle(control0);
        control0.setOnAction(event -> {
            Controller.clickControlButton(0,board);
        });


        controlPane.add(control1,0,0);
        controlPane.add(control2,1,0);
        controlPane.add(control3,2,0);
        controlPane.add(control4,0,2);
        controlPane.add(control5,1,2);
        controlPane.add(control6,2,2);
        controlPane.add(control7,0,3);
        controlPane.add(control8,1,3);
        controlPane.add(control9,2,3);
        controlPane.add(control0,1,4);




        // -----label with information about move----

        Label infoLabel = new Label("Welcome!");
        Controller.setInfoLabelStyle(infoLabel);
        board.infoLabel = infoLabel;

        // ----------------undo redo buttons -------


        Button undoButton = new Button("⮜");
        Controller.setUndoRedoStyle(undoButton);
        undoButton.setOnAction(event -> {
            Controller.undoMove(board);
        });

        Button redoButton = new Button("⮞");
        Controller.setUndoRedoStyle(redoButton);
        redoButton.setOnAction(event -> {
            Controller.redoMove(board);
        });

        HBox undoRedoBox = new HBox(undoButton, redoButton);
        undoRedoBox.setSpacing(30);

        //---------- SAVE and LOAD -------------------------------

        Button saveButton = new Button("Save");
        Controller.setSaveLoadStyle(saveButton);
        Button loadButton = new Button("Load");
        Controller.setSaveLoadStyle(loadButton);

        HBox saveAndLoadBox = new HBox(saveButton, loadButton);


        // ------------------------------------- control panel box ---------------------------------

        VBox controlPanel = new VBox(infoLabel,controlPane, undoRedoBox, saveAndLoadBox);
        controlPanel.setSpacing(10);
        controlPanel.setPadding( new Insets(25));
        controlPanel.setAlignment(Pos.CENTER);
        controlPanel.setOpacity(0.8);


        //------------------------------------------------------------------------------------------
        //-------------------------------- GAME BOX CONFIGURATION-----------------------------------
        //------------------------------------------------------------------------------------------
        HBox gameBox = new HBox(grid1, controlPanel);
        gameBox.setPadding(new Insets(10));
        gameBox.setStyle("-fx-pref-width: 400; -fx-pref-height: 1000");

        Image image = new Image("file:C:\\Users\\SAugustyniak1\\Desktop\\TMPL\\untitled27\\src\\sample\\space.jpeg");
        BackgroundSize backgroundSize = new BackgroundSize(600, 1000, true, true, true, false);
        BackgroundImage backgroundImage = new BackgroundImage(image, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.CENTER, backgroundSize);
        Background background = new Background(backgroundImage);
        gameBox.setBackground(background);

        Scene gameScene = new Scene(gameBox, 700, 580);

        primaryStage.setScene(gameScene);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
