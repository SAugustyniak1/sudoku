package sample;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Controller {

    // button in game style
    public static void setButtonStyle(ButtonWithID button, Board board) {

        // different buttons has different border
        // ----------------------------------------- row 1 ----------------------------------------------------------
        if (button.ID == 100) {
            if (board.takenBoard[0][0] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 101) {
            if (board.takenBoard[0][1] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 102) {
            if (board.takenBoard[0][2] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 103) {
            if (board.takenBoard[0][3] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 104) {
            if (board.takenBoard[0][4] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 105) {
            if (board.takenBoard[0][5] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 106) {
            if (board.takenBoard[0][6] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 107) {
            if (board.takenBoard[0][7] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 108) {
            if (board.takenBoard[0][8] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 4 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 4 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }
        // different buttons has different border
        // ----------------------------------------- row 2 ----------------------------------------------------------

        if (button.ID == 110) {
            if (board.takenBoard[1][0] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 111) {
            if (board.takenBoard[1][1] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 112) {
            if (board.takenBoard[1][2] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 113) {
            if (board.takenBoard[1][3] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 114) {
            if (board.takenBoard[1][4] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 115) {
            if (board.takenBoard[1][5] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 116) {
            if (board.takenBoard[1][6] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 117) {
            if (board.takenBoard[1][7] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 118) {
            if (board.takenBoard[1][8] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 4 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 4 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }
        // different buttons has different border
        // ----------------------------------------- row 3 ----------------------------------------------------------

        if (button.ID == 120) {
            if (board.takenBoard[2][0] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 121) {
            if (board.takenBoard[2][1] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 122) {
            if (board.takenBoard[2][2] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 123) {
            if (board.takenBoard[2][3] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 124) {
            if (board.takenBoard[2][4] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 125) {
            if (board.takenBoard[2][5] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 126) {
            if (board.takenBoard[2][6] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 127) {
            if (board.takenBoard[2][7] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 128) {
            if (board.takenBoard[2][8] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 4 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 4 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }
        // different buttons has different border
        // ----------------------------------------- row 4 ----------------------------------------------------------

        if (button.ID == 130) {
            if (board.takenBoard[3][0] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 131) {
            if (board.takenBoard[3][1] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 132) {
            if (board.takenBoard[3][2] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 133) {
            if (board.takenBoard[3][3] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 134) {
            if (board.takenBoard[3][4] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 135) {
            if (board.takenBoard[3][5] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 136) {
            if (board.takenBoard[3][6] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 137) {
            if (board.takenBoard[3][7] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 138) {
            if (board.takenBoard[3][8] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 4 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 4 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }
        // different buttons has different border
        // ----------------------------------------- row 5 ----------------------------------------------------------

        if (button.ID == 140) {
            if (board.takenBoard[4][0] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 141) {
            if (board.takenBoard[4][1] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 142) {
            if (board.takenBoard[4][2] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 143) {
            if (board.takenBoard[4][3] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 144) {
            if (board.takenBoard[4][4] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 145) {
            if (board.takenBoard[4][5] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 146) {
            if (board.takenBoard[4][6] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 147) {
            if (board.takenBoard[4][7] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 148) {
            if (board.takenBoard[4][8] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 4 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 4 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }
        // different buttons has different border
        // ----------------------------------------- row 6 ----------------------------------------------------------

        if (button.ID == 150) {
            if (board.takenBoard[5][0] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 151) {
            if (board.takenBoard[5][1] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 152) {
            if (board.takenBoard[5][2] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 153) {
            if (board.takenBoard[5][3] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 154) {
            if (board.takenBoard[5][4] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 155) {
            if (board.takenBoard[5][5] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 156) {
            if (board.takenBoard[5][6] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 157) {
            if (board.takenBoard[5][7] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 158) {
            if (board.takenBoard[5][8] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 4 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 4 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }
        // different buttons has different border
        // ----------------------------------------- row 7 ----------------------------------------------------------

        if (button.ID == 160) {
            if (board.takenBoard[6][0] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 161) {
            if (board.takenBoard[6][1] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 162) {
            if (board.takenBoard[6][2] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 163) {
            if (board.takenBoard[6][3] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 164) {
            if (board.takenBoard[6][4] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 165) {
            if (board.takenBoard[6][5] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 166) {
            if (board.takenBoard[6][6] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 167) {
            if (board.takenBoard[6][7] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 168) {
            if (board.takenBoard[6][8] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 4 4 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 4 4 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }
        // different buttons has different border
        // ----------------------------------------- row 8 ----------------------------------------------------------

        if (button.ID == 170) {
            if (board.takenBoard[7][0] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 171) {
            if (board.takenBoard[7][1] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 172) {
            if (board.takenBoard[7][2] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 173) {
            if (board.takenBoard[7][3] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 174) {
            if (board.takenBoard[7][4] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 175) {
            if (board.takenBoard[7][5] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 176) {
            if (board.takenBoard[7][6] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 177) {
            if (board.takenBoard[7][7] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 178) {
            if (board.takenBoard[7][8] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 4 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 4 1 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }
        // different buttons has different border
        // ----------------------------------------- row 9 ----------------------------------------------------------

        if (button.ID == 180) {
            if (board.takenBoard[8][0] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 4 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 4 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 181) {
            if (board.takenBoard[8][1] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 4 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 4 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 182) {
            if (board.takenBoard[8][2] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 4 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 4 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 183) {
            if (board.takenBoard[8][3] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 4 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 4 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 184) {
            if (board.takenBoard[8][4] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 4 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 4 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 185) {
            if (board.takenBoard[8][5] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 4 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 4 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 186) {
            if (board.takenBoard[8][6] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 4 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 4 4; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 187) {
            if (board.takenBoard[8][7] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 1 4 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 1 4 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }

        if (button.ID == 188) {
            if (board.takenBoard[8][8] == 0) {
                button.setStyle("-fx-background-color: #b0cfe5; -fx-border-width: 1 4 4 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            } else {
                button.setStyle("-fx-background-color: #468cba; -fx-border-width: 1 4 4 1; -fx-border-color: black; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");
            }
        }


    }

    // click a field and make it selected
    public static void clickButton(ButtonWithID button, Board board) {
        ButtonWithID previousSelectedButton = board.selectedButton;
        setButtonStyle(previousSelectedButton, board);

        board.selectedButton = button;
        button.setStyle("-fx-background-color: #977f9f; -fx-border-width: 1 1 1 1; -fx-border-color: #a91717; -fx-pref-width: 50; -fx-pref-height: 50; -fx-font-size: 20");

    }

    // number button in control panel style
    public static void setControlButtonStyle(Button button) {
        button.setStyle("-fx-background-color: #6d3eab; -fx-border-width: 1 1 1 1; -fx-border-color: #341047; -fx-pref-width: 30; -fx-pref-height: 50; -fx-font-size: 20; -fx-font-weight: bold");

    }

    // ---------------------------------------------------------------------------------------------------------------
    // click on control button change number inside selected button if its possible
    public static void clickControlButton(int number, Board board) {

        int[] coordinates = board.selectedButton.changeIDtoCoordinates();
        int previousNumber = board.board[coordinates[0]][coordinates[1]];


        if (Player.Move(coordinates[0], coordinates[1], number, board.board, board.takenBoard)) {
            board.historyCounter.x++;

            if(board.moveHistoryUndo.containsKey(board.historyCounter)){
                board.moveHistoryUndo.remove(board.historyCounter);
                board.moveHistoryRedo.remove(board.historyCounter);
            }

            board.moveHistoryUndo.put(board.historyCounter.x,(new Move(coordinates[0],coordinates[1],previousNumber, board.selectedButton )));
            board.moveHistoryRedo.put(board.historyCounter.x,(new Move(coordinates[0],coordinates[1],number, board.selectedButton )));


            if (number == 0 ) {
                board.selectedButton.setText("");
                board.infoLabel.setText("OK!");
            } else {
                board.selectedButton.setText(Integer.toString(number));
                if(Checker.checkWinner(board.board)){
                    board.infoLabel.setText("You won!");
                }else{
                    board.infoLabel.setText("OK!");
                }
            }
        }else{
            board.infoLabel.setText("Wrong Move!");
        }
    }

    // ----------------------------------- style info and undo redo save load buttons ---------------------------------

    public static void setInfoLabelStyle(Label label){
        label.setStyle("-fx-background-color: #9696cb; -fx-border-width: 3 3 3 3; -fx-border-color: #4e1342; -fx-pref-width: 120; -fx-pref-height: 30; -fx-font-size: 15; -fx-alignment:center");

    }

    public static void setUndoRedoStyle(Button button){
        button.setStyle("-fx-background-color: #9696cb; -fx-border-width: 3 3 3 3; -fx-border-color: #4e1342; -fx-pref-width: 45; -fx-pref-height: 20; -fx-font-size: 20; -fx-alignment:center; -fx-padding: 0 0 0 0");

    }

    public static void setSaveLoadStyle(Button button){
        button.setStyle("-fx-background-color: #9696cb; -fx-border-width: 3 3 3 3; -fx-border-color: #4e1342; -fx-pref-width: 61; -fx-pref-height: 20; -fx-font-size: 20; -fx-alignment:center; -fx-padding: 0 0 0 0");

    }

    // -------------------------- undo redo moves -------------------------------------------------------------------

    public static void undoMove(Board board){

        Move move = board.moveHistoryUndo.get(board.historyCounter.x);

        if(board.moveHistoryUndo.containsKey(board.historyCounter.x)){

            board.board[move.firstCoordinate][move.secondCoordinate] = move.number;
            if(move.number == 0){
                move.buttonInHistory.setText("");
            }else {
                move.buttonInHistory.setText(Integer.toString(move.number));
            }
            board.historyCounter.x--;

        }
    }

    public static void redoMove(Board board){

        if(board.moveHistoryRedo.containsKey(board.historyCounter.x +1)){

            board.historyCounter.x++;

            Move move = board.moveHistoryRedo.get(board.historyCounter.x);
            board.board[move.firstCoordinate][move.secondCoordinate] = move.number;
            if(move.number == 0){
                move.buttonInHistory.setText("");
            }else {
                move.buttonInHistory.setText(Integer.toString(move.number));
            }

        }
    }
}