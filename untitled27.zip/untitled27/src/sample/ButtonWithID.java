package sample;

import javafx.scene.control.Button;

public class ButtonWithID extends Button {

    int ID;

    public ButtonWithID(int ID) {
        this.ID = ID;
    }

    public int[] changeIDtoCoordinates(){
        String stringID = Integer.toString(this.ID);
        int[] coordinates = new int[2];
        coordinates[0] = Integer.parseInt(stringID.substring(1,2));
        coordinates[1] = Integer.parseInt(stringID.substring(2,3));
        return coordinates;
    }



}
