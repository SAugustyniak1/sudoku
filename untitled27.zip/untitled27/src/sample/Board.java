package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.Border;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Board {

    int [][] board = new int[9][9];

    int[][] takenBoard = new int[9][9];

    ButtonWithID selectedButton = new ButtonWithID(99999);

    Label infoLabel;

    HashMap<Integer, Move> moveHistoryUndo = new HashMap<>();
    HashMap<Integer, Move> moveHistoryRedo = new HashMap<>();

    HistoryCounter historyCounter = new HistoryCounter();

    Label movesCounter;
    AllHistoryCounter allHistoryCounter = new AllHistoryCounter();



    Board(int mapNumber){
        RandomMachine random = new RandomMachine();
        this.board = random.randomBoard(mapNumber);

        for (int i=0; i<9; i++){
            for(int j=0; j<9; j++){
                if(board[i][j] ==0){
                    takenBoard[i][j] = 0;
                }else {
                    takenBoard[i][j] = board[i][j];
                }
            }
        }

    }






}
