package sample;

public class Move {

    int firstCoordinate;
    int secondCoordinate;
    int number;
    ButtonWithID buttonInHistory = new ButtonWithID(99999);


    public Move(int firstCoordinate, int secondCoordinate, int number, ButtonWithID buttonInHistory) {
        this.firstCoordinate = firstCoordinate;
        this.secondCoordinate = secondCoordinate;
        this.number = number;
        this.buttonInHistory = buttonInHistory;
    }
}
